<?php

use App\Http\Controllers\ProductController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Lap1Controller;
use App\Http\Controllers;

//Method http
// GET, Post,PUT,PATCH,DELETE
// Base url: http://127.0.0.1:8000/

Route::get('/danh-sach-san-pham', function () {
    return view('welcome');
});
// //http://127.0.0.1:8000/
// Route::get('/danh-sach-san-pham', function () {
//     return view('welcome');
// });
// list-product
Route::get('list-product', [ProductController::class, 'showProduct']);

// slug 
//http://127.0.0.1:8000/list-product/1/iphone
Route::get('get-product/{id}',[ProductController::class, 'getProduct']);

//vs params
//http://127.0.0.1:8000/list-product?id=1
Route::get('update-product',[ProductController::class, 'updateProduct']);
Route::get('list-tensv',[Lap1Controller::class, 'listTensv']);
// CRUD => query builder
Route::group([
    'prefix' => 'users',
    'as' =>'users.'
],function(){
    //http://127.0.0.1:8000/users/list-users
    Route::get('list-users',[UserController::class, 'listUsers'])->name('listUsers');
    //http://127.0.0.1:8000/users/add-users
    Route::get('add-users',[UserController::class, 'addUsers'])->name('addUsers');

    Route::post('add-users',[UserController::class, 'addPostUsers'])->name('addPostUsers');
    Route::get('delete-users/{userId}',[UserController::class, 'deleteUsers'])->name('deleteUsers');
});