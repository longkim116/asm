<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function showProduct(){
        // $product = [
        //     [
        //         'id' => '1',
        //         'name' => 'iphone 14'
        //     ],
        //     [
        //         'id' => '2',
        //         'name' => 'samsung '
        //     ]
        // ];
        // return view('list-product')->with([
        //     'products' => $product
        // ]);
        // lay toan bo user (select * frome user )
        // $result = DB::table('users')->where('id','=','4')->first();
        // $result = DB::table('users')->find('4');//chi dung vowi id

        // lấy thuộc tính 'name' của user có id= 16
        // $result = DB::table('users')
        // ->where('id','=','16')
        // ->value('name');
        // dd ($result);
        // 4.lấy danh sách idUsers của phòng ban "ban giám hiệu"
        $idPhongban = DB::table('phongban')
            ->where('ten_donvi','like','Ban giam hieu')
            ->value('id');
        $result = DB::table('users')
        ->Where('phongban_id','=',$idPhongban)
        ->pluck('id');
        // 5. tìm user có độ tuổi lớn nhất trong công ty
        $sesult = DB::table('users')
        ->where('tuoi', DB::table('users')->max('tuoi'))
        ->get();
        // 6. tìm users có độ tuoir nhỏ nhất trong công ty
        $sesult = DB::table('users')
        ->where('tuoi', DB::table('users')->min('tuoi'))
        ->get();
        // 7. đếm xem phòng ban 'ban giam hieu' có bao nhiêu users
        // $sesult = DB::table('phongban')
        // ->where('ten_donvi',('like'),('Ban giám hiệu'))
        // ->value('id');
        // $result = DB::table('users')
        // ->wheres('phongban_id','=', $idPhongban)
        // ->count();
        // 8. lấy danh sách tuổi của các users
        $result = DB::table('users')->distinct()->pluck('tuoi');
        //9. Tìm danh sách user có tên 'Khải' hoặc có tên 'Thanh'
        $result = DB::table('users')
        ->where('name',('like'),'%khải')
        ->orWhere('name',('like'),'$thanh');
        
        //    10. Lấy danh sách user ở phòng ban 'Ban đào tạo'
        // $idPhongban = DB:: table('phongban')
        // ->where('ten_donvi', 'like', 'Ban đào tạo')
        // ->value('id','name','email')
        // ->value('id');
        
        //11. Lấy danh sách user có tuổi lớn hơn hoặc bằng 30, danh sách sắp xếp tăng dần
        $result = DB::table('users')
        -> where('tuoi','>=','30')
        ->orderBy('tuoi','asc')
        ->get();
        //12. Lấy danh sách 10 user sắp xếp giảm dần độ tuổi, bỏ qua 5 user đầu tiên
        $result = DB::table('users')
        ->orderBy('tuoi',('desc'))
        ->offset(5)
        ->limit(10)
        ->get();
        //13. Thêm một user mới vào công ty
        $data = [
            'name' => 'Nguyễn Văn A',
            'email' => 'abc@gmail.com',
            'phongban_id' => '1',
            'songaynghi' => '0',
            'tuoi' => '18',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ];
        $usersID = DB::table('users')->insertGetId($data);
        //14. Thêm chữ 'PĐT' sau tên tất cả user ở phòng ban 'Ban đào tạo'
        $idPhongban = DB::table('phongban')
        ->where('ten_donvi','like','Ban giam hieu')
        ->value('id');
        $listUser = DB::table('users')
        ->Where('phongban_id','=',$idPhongban)
        ->get();
        foreach($listUser as $value){
            DB::table('users')->wheres('id','=',$value->id)
            ->update([
                'name' => $value->name. 'PĐT'
            ]);
        }
        //15. Xóa user nghỉ quá 15 ngày
        DB::table('users')->where('songaynghi','>','15')->delete();
        dd($result);
    }
    
    public function getProduct($id){
        echo 'hello';
    }
    public function updateProduct(Request $request){
        echo $request->id;
        echo $request->name;
    }
}
