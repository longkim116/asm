<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Lap1Controller extends Controller
{
    public function tenSV(){
        $tenSV = [
            [
                'id' => '1',
                'name' => 'Nguyễn Kim Long',
                'nganhHoc' => 'cntt'
            ]
        ];
        return view('list-tensv')->with([
            'tensv' => $tenSV
        ]);
    }
}
